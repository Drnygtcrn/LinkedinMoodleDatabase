insert into PersonGroup(group_sector, group_name) values ('Yazılım', 'Yazılım Mühendisliği Staj');
insert into PersonGroup(group_sector, group_name) values ('Mekatronik', 'Mekatronik Münedisliği Gönüllüleri');
insert into PersonGroup(group_sector, group_name) values ('pazarlama', 'Pazarlamacılar');
insert into PersonGroup(group_sector, group_name) values ('kimya_mühendisliği', 'Kimyacılar');
insert into PersonGroup(group_sector, group_name) values ('Mühendislik', 'Mühendisler Odası');
insert into PersonGroup(group_sector, group_name) values ('Ekoloji', 'Çevre Koruma Grubu');