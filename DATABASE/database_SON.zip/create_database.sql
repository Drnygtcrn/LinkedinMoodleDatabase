drop database if exists linkedinmoodle;

create database LinkedinMoodle;

use linkedinmoodle;