insert into Course(semester, course_name, department, course_year, enroll_key, instructor_id) values ('FALL', 'Chemistry-101', 'Kimya Mühendisliği', 2022, 'intro_chemistry22', 7);
insert into Course(semester, course_name, department, course_year, enroll_key, instructor_id) values ('FALL', 'Calculus','Kimya Mühendisliği', 2022,'calculus2022',41);
insert into Course(semester, course_name, department, course_year, enroll_key, instructor_id) values ('FALL', 'Database Management', 'Bilgisayar Mühendisliği', 2022, 'dbmanagement_22', 53);
insert into Course(semester, course_name, department, course_year, enroll_key, instructor_id) values ('SPRING', 'History','Mekatronik Mühendisliği',2022,'y90xyIHdDASFzlLzr',52);
insert into Course(semester, course_name, department, course_year, enroll_key, instructor_id) values ('SPRING', 'Digital Computer Design', 'Makine Mühendisliği', 2022, 'digitbir01cd', 8);

insert into Course(semester, course_name, department, course_year, enroll_key, instructor_id) values ('FALL', 'MDT', 'Makine Mühendisliği', 2021, 'mantikbir01cd', 8);
